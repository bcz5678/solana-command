/**
 * solana-dev-wallet-flow-analyzer
 * -----------------------------------------------------------------------------
 * Given a token-launch dev wallet + a time window, this reconstructs the full
 * trading flow around that launch:
 *
 *   1. Find every Address Lookup Table (ALT) the dev wallet created/extended,
 *      and resolve the addresses stored in those tables.
 *   2. Find every token mint the dev wallet created in the window (pump.fun
 *      `create` ix, or a raw SPL `initializeMint`/`initializeMint2`).
 *   3. Pull every transaction that touched that mint in the window (covers
 *      both the pump.fun bonding-curve phase AND the post-migration AMM pool,
 *      since both phases still reference the mint account).
 *   4. For every wallet that traded, walk back to find its FUNDING wallet
 *      (the account that sent it its first SOL), and any other wallets that
 *      same funder also funded in-window ("sibling" wallets).
 *   5. Build an "associated wallet" set = dev wallet ∪ ALT-table addresses
 *      ∪ funders of those ∪ siblings of those funders.
 *   6. Classify every trade made by an associated wallet (buy/sell, SOL size,
 *      token size) using balance deltas, and roll up running PnL per wallet
 *      and in aggregate, in chronological order.
 *   7. Emit a console table, a CSV, and a JSON file suitable for charting.
 *
 * IMPORTANT CAVEATS (read before trusting the output):
 * -----------------------------------------------------------------------------
 * - You need an archival-friendly RPC (Helius / QuickNode / Triton). Public
 *   RPC endpoints cap and throttle getSignaturesForAddress hard and will give
 *   you an incomplete picture silently.
 * - "Funding wallet" = the sender of the EARLIEST incoming SOL transfer seen
 *   for an address. This is the standard heuristic for wallet clustering, but
 *   it's a heuristic, not proof of common control. CEX withdrawal wallets,
 *   for instance, will make totally unrelated wallets look "linked" to each
 *   other because they all get first-funded by the exchange's hot wallet.
 *   `KNOWN_EXCHANGE_HOTWALLETS` below lets you exclude common ones.
 * - pump.fun's on-chain program has changed shape across versions. The
 *   anchor discriminators here are computed at runtime from the current
 *   instruction names, so they self-correct as long as the *names* haven't
 *   changed — but if pump.fun ships a new program with new instruction names
 *   entirely, this needs an update. Same caveat applies to the AMM program id
 *   used for migrated pools — verify it's still current before relying on it.
 * - Trade classification is balance-delta based (pre/post SOL + token
 *   balances for the wallet's own accounts), NOT instruction-layout based.
 *   That makes it robust across bonding-curve vs. AMM-pool phases, but it
 *   means multi-hop/aggregator transactions (e.g. Jupiter routing through
 *   several pools in one tx) will be attributed to net effect only, not
 *   per-hop.
 * - PnL uses average-cost-basis accounting per (wallet, mint). It reports
 *   realized PnL on sells and marks-to-market an "unrealized" line at the end
 *   using the last observed trade price — it is NOT a tax-grade FIFO/LIFO
 *   engine.
 *
 * Usage:
 *   npm install
 *   npx ts-node analyzer.ts \
 *     --dev <DEV_WALLET_PUBKEY> \
 *     --start 2026-06-01T00:00:00Z \
 *     --end   2026-06-08T00:00:00Z \
 *     --rpc   https://your-archival-rpc-endpoint
 */

import {
  Connection,
  PublicKey,
  ParsedTransactionWithMeta,
  ConfirmedSignatureInfo,
  ParsedInstruction,
  PartiallyDecodedInstruction,
} from "@solana/web3.js";
import bs58 from "bs58";
import { createHash } from "crypto";
import * as fs from "fs";
import * as path from "path";

// ============================================================================
// CONFIG
// ============================================================================

interface CliConfig {
  devWallet: string;
  startTime: number; // unix seconds
  endTime: number; // unix seconds
  rpcUrl: string;
  outDir: string;
}

/** Known exchange / aggregator hot wallets to exclude from funding-graph
 *  clustering, since "funded by the same source" is meaningless for these. */
const KNOWN_EXCHANGE_HOTWALLETS = new Set<string>([
  // Add known CEX hot wallets / faucets here as you identify them, e.g.:
  // "5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9", // Binance hot wallet (example)
]);

const SYSTEM_PROGRAM_ID = "11111111111111111111111111111111";
const TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const TOKEN_2022_PROGRAM_ID = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb";
const ALT_PROGRAM_ID = "AddressLookupTab1e1111111111111111111111111";

// pump.fun bonding-curve program. Verify this is still current for your window.
const PUMPFUN_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";

// Programs a mint might trade through post-migration. Extend this list if you
// track other migration destinations (e.g. Raydium CPMM, Meteora, etc).
const MIGRATION_PROGRAM_IDS = new Set<string>([
  "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA", // pump.fun AMM (post-migration) — verify current
  "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", // Raydium AMM V4
]);

const TRADE_PROGRAM_IDS = new Set<string>([
  PUMPFUN_PROGRAM_ID,
  ...MIGRATION_PROGRAM_IDS,
]);

// How many signatures to request per getSignaturesForAddress page.
const SIG_PAGE_SIZE = 1000;

// Delay between RPC calls to stay under rate limits. Tune for your provider.
const RPC_DELAY_MS = 150;

function sleep(ms: number) {
  return new Promise((res) => setTimeout(res, ms));
}

/** Computes an Anchor instruction discriminator: first 8 bytes of
 *  sha256("global:<instruction_name>"). Used to identify pump.fun
 *  instructions (create/buy/sell) from raw, un-parsed instruction data. */
function anchorDiscriminator(instructionName: string): Buffer {
  return createHash("sha256")
    .update(`global:${instructionName}`)
    .digest()
    .subarray(0, 8);
}

const DISC_CREATE = anchorDiscriminator("create");
const DISC_BUY = anchorDiscriminator("buy");
const DISC_SELL = anchorDiscriminator("sell");

// ============================================================================
// GENERIC RPC PAGINATION HELPERS
// ============================================================================

/**
 * Fetches ALL confirmed signatures for `address` whose blockTime falls in
 * [startTime, endTime] (inclusive), paginating backwards from the chain tip
 * (or from `beforeSig` if given) using the `before` cursor.
 *
 * NOTE: getSignaturesForAddress walks newest -> oldest. We keep paging until
 * either we've walked past `startTime` or run out of history.
 */
async function fetchSignaturesInRange(
  connection: Connection,
  address: PublicKey,
  startTime: number,
  endTime: number,
  beforeSig?: string
): Promise<ConfirmedSignatureInfo[]> {
  const collected: ConfirmedSignatureInfo[] = [];
  let before: string | undefined = beforeSig;

  while (true) {
    const page: ConfirmedSignatureInfo[] = await connection.getSignaturesForAddress(
      address,
      { before, limit: SIG_PAGE_SIZE }
    );
    await sleep(RPC_DELAY_MS);

    if (page.length === 0) break;

    let hitFloor = false;
    for (const sig of page) {
      if (sig.blockTime == null) continue;
      if (sig.blockTime > endTime) continue; // still newer than our window
      if (sig.blockTime < startTime) {
        hitFloor = true;
        break;
      }
      collected.push(sig);
    }

    before = page[page.length - 1].signature;
    if (hitFloor) break;
    if (page.length < SIG_PAGE_SIZE) break; // exhausted history
  }

  return collected;
}

/** Fetches the OLDEST signature(s) for an address by paging all the way back.
 *  Used to find an account's very first transaction (its funding tx). Caps
 *  at `maxPages` pages as a safety valve for very old/busy wallets — if you
 *  hit the cap, the result may not actually be the wallet's true first tx. */
async function fetchOldestSignature(
  connection: Connection,
  address: PublicKey,
  maxPages = 50
): Promise<ConfirmedSignatureInfo | null> {
  let before: string | undefined = undefined;
  let last: ConfirmedSignatureInfo | null = null;

  for (let i = 0; i < maxPages; i++) {
    const page = await connection.getSignaturesForAddress(address, {
      before,
      limit: SIG_PAGE_SIZE,
    });
    await sleep(RPC_DELAY_MS);
    if (page.length === 0) break;
    last = page[page.length - 1];
    before = last.signature;
    if (page.length < SIG_PAGE_SIZE) break; // reached true oldest
  }
  return last;
}

async function getParsedTx(
  connection: Connection,
  signature: string
): Promise<ParsedTransactionWithMeta | null> {
  const tx = await connection.getParsedTransaction(signature, {
    maxSupportedTransactionVersion: 0,
  });
  await sleep(RPC_DELAY_MS);
  return tx;
}

function isParsedInstruction(
  ix: ParsedInstruction | PartiallyDecodedInstruction
): ix is ParsedInstruction {
  return (ix as ParsedInstruction).parsed !== undefined;
}

// ============================================================================
// STEP 1: ADDRESS LOOKUP TABLE (ALT) DISCOVERY
// ============================================================================

interface AltEvent {
  signature: string;
  blockTime: number;
  type: "create" | "extend";
  lookupTableAddress: string;
  authority: string;
  newAddresses?: string[]; // populated for "extend"
}

/**
 * Scans the dev wallet's transactions in-window for ALT create/extend
 * instructions. The Address Lookup Table program is natively understood by
 * RPC's jsonParsed encoding, so we get typed `.parsed.info` for free — no
 * manual instruction-layout decoding needed here.
 */
async function findAltEvents(
  connection: Connection,
  devWallet: PublicKey,
  startTime: number,
  endTime: number
): Promise<AltEvent[]> {
  const sigs = await fetchSignaturesInRange(connection, devWallet, startTime, endTime);
  const events: AltEvent[] = [];

  for (const sigInfo of sigs) {
    if (sigInfo.err) continue; // skip failed txs
    const tx = await getParsedTx(connection, sigInfo.signature);
    if (!tx || tx.blockTime == null) continue;

    const allInstructions = [
      ...tx.transaction.message.instructions,
      ...(tx.meta?.innerInstructions?.flatMap((i) => i.instructions) ?? []),
    ];

    for (const ix of allInstructions) {
      if (ix.programId.toBase58() !== ALT_PROGRAM_ID) continue;
      if (!isParsedInstruction(ix)) continue;

      const info = ix.parsed.info as any;
      if (ix.parsed.type === "createLookupTable") {
        events.push({
          signature: sigInfo.signature,
          blockTime: tx.blockTime,
          type: "create",
          lookupTableAddress: info.lookupTableAddress ?? info.newAccount ?? "unknown",
          authority: info.lookupTableAuthority ?? info.authority ?? devWallet.toBase58(),
        });
      } else if (ix.parsed.type === "extendLookupTable") {
        events.push({
          signature: sigInfo.signature,
          blockTime: tx.blockTime,
          type: "extend",
          lookupTableAddress: info.lookupTableAccount ?? info.lookupTableAddress ?? "unknown",
          authority: info.lookupTableAuthority ?? info.authority ?? devWallet.toBase58(),
          newAddresses: info.newAddresses ?? undefined,
        });
      }
    }
  }

  return events;
}

/** Resolves the full current address list stored in a lookup table. */
async function resolveLookupTableAddresses(
  connection: Connection,
  tableAddress: PublicKey
): Promise<string[]> {
  const result = await connection.getAddressLookupTable(tableAddress);
  await sleep(RPC_DELAY_MS);
  const account = result.value;
  if (!account) return [];
  return account.state.addresses.map((a) => a.toBase58());
}

// ============================================================================
// STEP 2: TOKEN (MINT) CREATION DISCOVERY
// ============================================================================

interface TokenCreationEvent {
  signature: string;
  blockTime: number;
  mint: string;
  source: "pumpfun" | "spl-initialize-mint";
}

/**
 * Scans the dev wallet's transactions in-window for:
 *   - pump.fun `create` instructions (anchor-discriminator matched), and
 *   - raw SPL Token / Token-2022 `initializeMint` / `initializeMint2`
 *     instructions (natively parsed by RPC).
 */
async function findTokenCreations(
  connection: Connection,
  devWallet: PublicKey,
  startTime: number,
  endTime: number
): Promise<TokenCreationEvent[]> {
  const sigs = await fetchSignaturesInRange(connection, devWallet, startTime, endTime);
  const events: TokenCreationEvent[] = [];

  for (const sigInfo of sigs) {
    if (sigInfo.err) continue;
    const tx = await getParsedTx(connection, sigInfo.signature);
    if (!tx || tx.blockTime == null) continue;

    const allInstructions = [
      ...tx.transaction.message.instructions,
      ...(tx.meta?.innerInstructions?.flatMap((i) => i.instructions) ?? []),
    ];

    for (const ix of allInstructions) {
      const programId = ix.programId.toBase58();

      // --- SPL / Token-2022 mint initialization (natively parsed) ---
      if (
        (programId === TOKEN_PROGRAM_ID || programId === TOKEN_2022_PROGRAM_ID) &&
        isParsedInstruction(ix) &&
        (ix.parsed.type === "initializeMint" || ix.parsed.type === "initializeMint2")
      ) {
        events.push({
          signature: sigInfo.signature,
          blockTime: tx.blockTime,
          mint: ix.parsed.info.mint,
          source: "spl-initialize-mint",
        });
        continue;
      }

      // --- pump.fun `create` (raw instruction, discriminator-matched) ---
      if (programId === PUMPFUN_PROGRAM_ID && !isParsedInstruction(ix)) {
        const raw = (ix as PartiallyDecodedInstruction).data;
        const dataBuf = Buffer.from(bs58.decode(raw));
        if (dataBuf.subarray(0, 8).equals(DISC_CREATE)) {
          // Account ordering for pump.fun's `create` ix: the new mint is
          // conventionally the first account. Verify against the current
          // pump.fun IDL if this ever misfires.
          const accounts = (ix as PartiallyDecodedInstruction).accounts;
          const mint = accounts?.[0]?.toBase58();
          if (mint) {
            events.push({
              signature: sigInfo.signature,
              blockTime: tx.blockTime,
              mint,
              source: "pumpfun",
            });
          }
        }
      }
    }
  }

  return events;
}

// ============================================================================
// STEP 3: ALL TRANSACTIONS AGAINST THE MINT IN-WINDOW
// ============================================================================

async function fetchMintTransactions(
  connection: Connection,
  mint: PublicKey,
  startTime: number,
  endTime: number
): Promise<ConfirmedSignatureInfo[]> {
  return fetchSignaturesInRange(connection, mint, startTime, endTime);
}

// ============================================================================
// STEP 4: FUNDING-WALLET TRACING & SIBLING DISCOVERY
// ============================================================================

/**
 * Finds the wallet that sent `wallet` its very first SOL (its "funder"), by
 * walking back to the oldest transaction involving `wallet` and locating the
 * System Program transfer/createAccount instruction that credited it.
 * Returns null if no funder can be identified (e.g. wallet was funded by a
 * program-derived transfer we can't attribute, or has no history).
 */
async function traceFundingWallet(
  connection: Connection,
  wallet: PublicKey
): Promise<{ funder: string; signature: string; blockTime: number } | null> {
  const oldestSig = await fetchOldestSignature(connection, wallet);
  if (!oldestSig) return null;

  const tx = await getParsedTx(connection, oldestSig.signature);
  if (!tx || tx.blockTime == null) return null;

  const allInstructions = [
    ...tx.transaction.message.instructions,
    ...(tx.meta?.innerInstructions?.flatMap((i) => i.instructions) ?? []),
  ];

  for (const ix of allInstructions) {
    if (ix.programId.toBase58() !== SYSTEM_PROGRAM_ID) continue;
    if (!isParsedInstruction(ix)) continue;

    const type = ix.parsed.type;
    if (type === "transfer" || type === "createAccount" || type === "createAccountWithSeed") {
      const info = ix.parsed.info as any;
      const destination = info.destination ?? info.newAccount;
      if (destination === wallet.toBase58()) {
        const source = info.source;
        return { funder: source, signature: oldestSig.signature, blockTime: tx.blockTime };
      }
    }
  }

  return null;
}

/**
 * Given a funder wallet, finds other wallets it sent SOL to within the
 * window — these are treated as candidate "sibling" wallets (commonly funded
 * from the same source, e.g. a bundler/funding wallet spinning up snipers).
 * Skips known exchange hot wallets since fan-out from those is meaningless.
 */
async function findSiblingWallets(
  connection: Connection,
  funder: PublicKey,
  startTime: number,
  endTime: number
): Promise<string[]> {
  if (KNOWN_EXCHANGE_HOTWALLETS.has(funder.toBase58())) return [];

  const sigs = await fetchSignaturesInRange(connection, funder, startTime, endTime);
  const siblings = new Set<string>();

  for (const sigInfo of sigs) {
    if (sigInfo.err) continue;
    const tx = await getParsedTx(connection, sigInfo.signature);
    if (!tx) continue;

    const allInstructions = [
      ...tx.transaction.message.instructions,
      ...(tx.meta?.innerInstructions?.flatMap((i) => i.instructions) ?? []),
    ];

    for (const ix of allInstructions) {
      if (ix.programId.toBase58() !== SYSTEM_PROGRAM_ID) continue;
      if (!isParsedInstruction(ix)) continue;
      if (ix.parsed.type !== "transfer") continue;

      const info = ix.parsed.info as any;
      if (info.source === funder.toBase58() && info.destination !== funder.toBase58()) {
        siblings.add(info.destination);
      }
    }
  }

  return Array.from(siblings);
}

/**
 * Builds the full "associated wallet" set as specified:
 *   dev wallet
 *   ∪ addresses stored in the dev's ALT tables
 *   ∪ funders of (dev ∪ ALT addresses)
 *   ∪ wallets those funders also funded in-window ("siblings")
 *
 * Returns a map from wallet address -> a short reason string, so the trade
 * table can show *why* a wallet was included.
 */
async function buildAssociatedWalletGraph(
  connection: Connection,
  devWallet: PublicKey,
  altEvents: AltEvent[],
  startTime: number,
  endTime: number
): Promise<Map<string, string>> {
  const graph = new Map<string, string>();
  graph.set(devWallet.toBase58(), "dev wallet");

  // 1) Resolve ALT table contents.
  const tableAddresses = new Set<string>(altEvents.map((e) => e.lookupTableAddress));
  for (const tableAddr of tableAddresses) {
    try {
      const addrs = await resolveLookupTableAddresses(connection, new PublicKey(tableAddr));
      for (const a of addrs) {
        if (!graph.has(a)) graph.set(a, `ALT ${tableAddr.slice(0, 6)}…`);
      }
    } catch {
      // Table may have been closed/deactivated since — skip.
    }
  }

  // 2) Funders of dev + ALT addresses.
  const seedWallets = Array.from(graph.keys());
  const funders = new Set<string>();
  for (const w of seedWallets) {
    const result = await traceFundingWallet(connection, new PublicKey(w));
    if (result && !KNOWN_EXCHANGE_HOTWALLETS.has(result.funder)) {
      funders.add(result.funder);
      if (!graph.has(result.funder)) {
        graph.set(result.funder, `funder of ${w.slice(0, 6)}…`);
      }
    }
  }

  // 3) Siblings funded by the same funders, within window.
  for (const funder of funders) {
    const siblings = await findSiblingWallets(
      connection,
      new PublicKey(funder),
      startTime,
      endTime
    );
    for (const s of siblings) {
      if (!graph.has(s)) graph.set(s, `sibling via funder ${funder.slice(0, 6)}…`);
    }
  }

  return graph;
}

// ============================================================================
// STEP 5: TRADE CLASSIFICATION (balance-delta based)
// ============================================================================

interface Trade {
  signature: string;
  blockTime: number;
  wallet: string;
  walletReason: string;
  mint: string;
  side: "buy" | "sell";
  solDelta: number; // absolute SOL moved (always positive)
  tokenDelta: number; // absolute token amount moved (always positive), UI units
  pricePerToken: number; // SOL per token for this trade
  program: string; // which program the trade routed through
}

/**
 * Classifies trades for a single transaction by diffing pre/post SOL and
 * token balances for every account owned by an associated wallet. This is
 * intentionally program-agnostic: it works the same whether the trade
 * happened on the pump.fun bonding curve or a post-migration AMM pool,
 * because in both cases the trader's own SOL and token balances move in the
 * same recognizable way (SOL down + tokens up = buy; SOL up + tokens down =
 * sell).
 */
async function extractTradesFromTx(
  connection: Connection,
  sigInfo: ConfirmedSignatureInfo,
  mint: PublicKey,
  associatedWallets: Map<string, string>
): Promise<Trade[]> {
  if (sigInfo.err) return [];
  const tx = await getParsedTx(connection, sigInfo.signature);
  if (!tx || !tx.meta || tx.blockTime == null) return [];

  // Only consider transactions that actually touched a trade program, so we
  // don't misclassify unrelated transfers as trades.
  const programIds = new Set(
    tx.transaction.message.instructions.map((ix) => ix.programId.toBase58())
  );
  const touchesTradeProgram = Array.from(programIds).some((p) => TRADE_PROGRAM_IDS.has(p));
  if (!touchesTradeProgram) return [];

  const programUsed =
    Array.from(programIds).find((p) => TRADE_PROGRAM_IDS.has(p)) ?? "unknown";

  const accountKeys = tx.transaction.message.accountKeys.map((k) => k.pubkey.toBase58());
  const trades: Trade[] = [];

  // --- SOL balance deltas, per top-level account ---
  const solDeltaByOwner = new Map<string, number>(); // lamports, signed
  accountKeys.forEach((addr, idx) => {
    if (!associatedWallets.has(addr)) return;
    const pre = tx.meta!.preBalances[idx] ?? 0;
    const post = tx.meta!.postBalances[idx] ?? 0;
    solDeltaByOwner.set(addr, (solDeltaByOwner.get(addr) ?? 0) + (post - pre));
  });

  // --- Token balance deltas for the target mint, per owner ---
  const tokenDeltaByOwner = new Map<string, number>(); // UI amount, signed
  const preTok = tx.meta.preTokenBalances ?? [];
  const postTok = tx.meta.postTokenBalances ?? [];

  const preByKey = new Map<string, number>();
  for (const b of preTok) {
    if (b.mint !== mint.toBase58() || !b.owner) continue;
    preByKey.set(b.owner, (preByKey.get(b.owner) ?? 0) + (b.uiTokenAmount.uiAmount ?? 0));
  }
  const postByKey = new Map<string, number>();
  for (const b of postTok) {
    if (b.mint !== mint.toBase58() || !b.owner) continue;
    postByKey.set(b.owner, (postByKey.get(b.owner) ?? 0) + (b.uiTokenAmount.uiAmount ?? 0));
  }
  const allOwners = new Set([...preByKey.keys(), ...postByKey.keys()]);
  for (const owner of allOwners) {
    if (!associatedWallets.has(owner)) continue;
    const delta = (postByKey.get(owner) ?? 0) - (preByKey.get(owner) ?? 0);
    if (delta !== 0) tokenDeltaByOwner.set(owner, delta);
  }

  // --- Combine into trades: an associated wallet whose token balance went
  //     up while SOL went down is a buy; the inverse is a sell. ---
  for (const [owner, tokenDelta] of tokenDeltaByOwner) {
    const solDeltaLamports = solDeltaByOwner.get(owner) ?? 0;
    if (tokenDelta === 0) continue;

    const side: "buy" | "sell" = tokenDelta > 0 ? "buy" : "sell";
    const solAbs = Math.abs(solDeltaLamports) / 1e9;
    const tokenAbs = Math.abs(tokenDelta);
    if (tokenAbs === 0 || solAbs === 0) continue; // can't price a zero-cost leg

    trades.push({
      signature: sigInfo.signature,
      blockTime: tx.blockTime,
      wallet: owner,
      walletReason: associatedWallets.get(owner) ?? "unknown",
      mint: mint.toBase58(),
      side,
      solDelta: solAbs,
      tokenDelta: tokenAbs,
      pricePerToken: solAbs / tokenAbs,
      program: programUsed,
    });
  }

  return trades;
}

// ============================================================================
// STEP 6: PNL ENGINE (average-cost basis, per wallet+mint)
// ============================================================================

interface PnlRow extends Trade {
  realizedPnlSol: number; // realized on this trade only (0 for buys)
  cumulativeRealizedPnlSol: number; // running total for this wallet+mint
  positionAfter: number; // token position after this trade
  avgCostAfter: number; // avg cost basis (SOL/token) after this trade
}

interface CostBasisState {
  position: number; // tokens held
  avgCost: number; // SOL per token
  cumulativeRealized: number; // SOL
}

function computePnl(trades: Trade[]): PnlRow[] {
  // Chronological order is essential for cost-basis accounting.
  const sorted = [...trades].sort((a, b) => a.blockTime - b.blockTime);
  const state = new Map<string, CostBasisState>(); // key = wallet|mint
  const rows: PnlRow[] = [];

  for (const t of sorted) {
    const key = `${t.wallet}|${t.mint}`;
    const s = state.get(key) ?? { position: 0, avgCost: 0, cumulativeRealized: 0 };

    let realized = 0;
    if (t.side === "buy") {
      const newPosition = s.position + t.tokenDelta;
      const newCostBasisTotal = s.avgCost * s.position + t.pricePerToken * t.tokenDelta;
      s.avgCost = newPosition > 0 ? newCostBasisTotal / newPosition : 0;
      s.position = newPosition;
    } else {
      // sell
      const sellQty = Math.min(t.tokenDelta, s.position); // clamp against dust/rounding
      realized = (t.pricePerToken - s.avgCost) * sellQty;
      s.position -= sellQty;
      s.cumulativeRealized += realized;
      if (s.position <= 0) {
        s.position = 0;
        s.avgCost = 0;
      }
    }

    state.set(key, s);
    rows.push({
      ...t,
      realizedPnlSol: realized,
      cumulativeRealizedPnlSol: s.cumulativeRealized,
      positionAfter: s.position,
      avgCostAfter: s.avgCost,
    });
  }

  return rows;
}

/** Mark-to-market unrealized PnL for any wallet still holding a position at
 *  the end of the window, using the last observed trade price for that mint. */
function computeUnrealized(rows: PnlRow[]): Map<string, number> {
  const lastPriceByMint = new Map<string, number>();
  for (const r of rows) lastPriceByMint.set(r.mint, r.pricePerToken); // last write wins (chrono order)

  const openPositions = new Map<string, { position: number; avgCost: number; mint: string }>();
  for (const r of rows) {
    const key = `${r.wallet}|${r.mint}`;
    openPositions.set(key, { position: r.positionAfter, avgCost: r.avgCostAfter, mint: r.mint });
  }

  const unrealized = new Map<string, number>();
  for (const [key, pos] of openPositions) {
    if (pos.position <= 0) continue;
    const lastPrice = lastPriceByMint.get(pos.mint) ?? pos.avgCost;
    unrealized.set(key, (lastPrice - pos.avgCost) * pos.position);
  }
  return unrealized;
}

// ============================================================================
// STEP 7: OUTPUT — console table, CSV, and chart-ready JSON
// ============================================================================

function toCsv(rows: PnlRow[]): string {
  const header = [
    "blockTime",
    "isoTime",
    "signature",
    "wallet",
    "walletReason",
    "mint",
    "program",
    "side",
    "solAmount",
    "tokenAmount",
    "pricePerToken",
    "realizedPnlSol",
    "cumulativeRealizedPnlSol",
    "positionAfter",
  ].join(",");

  const lines = rows.map((r) =>
    [
      r.blockTime,
      new Date(r.blockTime * 1000).toISOString(),
      r.signature,
      r.wallet,
      `"${r.walletReason}"`,
      r.mint,
      r.program,
      r.side,
      r.solDelta.toFixed(9),
      r.tokenDelta.toFixed(6),
      r.pricePerToken.toFixed(12),
      r.realizedPnlSol.toFixed(9),
      r.cumulativeRealizedPnlSol.toFixed(9),
      r.positionAfter.toFixed(6),
    ].join(",")
  );

  return [header, ...lines].join("\n");
}

/** Quick, dependency-free ASCII sparkline of aggregate cumulative realized
 *  PnL over time, so you get a feel for the flow without leaving the
 *  terminal. The JSON output is what you'd feed into a real charting lib
 *  (e.g. a Chart.js/Recharts artifact) for something presentable. */
function printAsciiPnlChart(rows: PnlRow[], width = 60, height = 12) {
  if (rows.length === 0) {
    console.log("(no trades to chart)");
    return;
  }

  // Aggregate cumulative realized PnL across ALL associated wallets, in
  // chronological order (rows are already sorted by computePnl).
  let running = 0;
  const series = rows.map((r) => (running += r.realizedPnlSol));

  const min = Math.min(0, ...series);
  const max = Math.max(0, ...series);
  const range = max - min || 1;

  // Downsample to `width` points if there are more trades than columns.
  const step = Math.max(1, Math.ceil(series.length / width));
  const sampled: number[] = [];
  for (let i = 0; i < series.length; i += step) sampled.push(series[i]);

  const grid: string[][] = Array.from({ length: height }, () => Array(sampled.length).fill(" "));
  sampled.forEach((v, col) => {
    const row = Math.round(((v - min) / range) * (height - 1));
    grid[height - 1 - row][col] = "*";
  });

  console.log(`\nAggregate cumulative realized PnL (SOL) — chronological\n`);
  console.log(`  max: ${max.toFixed(4)} SOL`);
  grid.forEach((row) => console.log("  " + row.join("")));
  console.log(`  min: ${min.toFixed(4)} SOL`);
  console.log(`  (${series.length} trades, sampled every ${step})\n`);
}

function printConsoleSummary(rows: PnlRow[], graph: Map<string, string>) {
  console.log(`\n=== Associated wallets (${graph.size}) ===`);
  for (const [addr, reason] of graph) {
    console.log(`  ${addr}  (${reason})`);
  }

  console.log(`\n=== Trades in window (${rows.length}) ===`);
  console.table(
    rows.map((r) => ({
      time: new Date(r.blockTime * 1000).toISOString(),
      wallet: r.wallet.slice(0, 8) + "…",
      side: r.side,
      sol: r.solDelta.toFixed(4),
      tokens: r.tokenDelta.toFixed(2),
      price: r.pricePerToken.toExponential(4),
      realizedPnl: r.realizedPnlSol.toFixed(4),
      cumPnl: r.cumulativeRealizedPnlSol.toFixed(4),
      program: r.program.slice(0, 6) + "…",
    }))
  );

  const unrealized = computeUnrealized(rows);
  const totalRealized = rows.reduce((sum, r) => sum + r.realizedPnlSol, 0);
  const totalUnrealized = Array.from(unrealized.values()).reduce((a, b) => a + b, 0);

  console.log(`\nTotal realized PnL (associated wallets): ${totalRealized.toFixed(4)} SOL`);
  console.log(`Total unrealized PnL (open positions):    ${totalUnrealized.toFixed(4)} SOL`);
  console.log(`Net: ${(totalRealized + totalUnrealized).toFixed(4)} SOL`);
}

// ============================================================================
// MAIN ORCHESTRATION
// ============================================================================

function parseArgs(): CliConfig {
  const args = process.argv.slice(2);
  const get = (flag: string): string | undefined => {
    const i = args.indexOf(flag);
    return i >= 0 ? args[i + 1] : undefined;
  };

  const devWallet = get("--dev");
  const start = get("--start");
  const end = get("--end");
  const rpcUrl = get("--rpc");
  const outDir = get("--out") ?? "./out";

  if (!devWallet || !start || !end || !rpcUrl) {
    console.error(
      "Usage: ts-node analyzer.ts --dev <PUBKEY> --start <ISO8601> --end <ISO8601> --rpc <RPC_URL> [--out <dir>]"
    );
    process.exit(1);
  }

  return {
    devWallet,
    startTime: Math.floor(new Date(start).getTime() / 1000),
    endTime: Math.floor(new Date(end).getTime() / 1000),
    rpcUrl,
    outDir,
  };
}

async function main() {
  const config = parseArgs();
  const connection = new Connection(config.rpcUrl, "confirmed");
  const devWallet = new PublicKey(config.devWallet);

  console.log(`Analyzing dev wallet ${config.devWallet}`);
  console.log(
    `Window: ${new Date(config.startTime * 1000).toISOString()} -> ${new Date(
      config.endTime * 1000
    ).toISOString()}`
  );

  // --- Step 1: ALT events ---
  console.log("\n[1/6] Scanning for Address Lookup Table create/extend events…");
  const altEvents = await findAltEvents(connection, devWallet, config.startTime, config.endTime);
  console.log(`  found ${altEvents.length} ALT event(s)`);

  // --- Step 2: token creations ---
  console.log("[2/6] Scanning for token creations…");
  const creations = await findTokenCreations(
    connection,
    devWallet,
    config.startTime,
    config.endTime
  );
  console.log(`  found ${creations.length} token creation event(s)`);
  if (creations.length === 0) {
    console.log("No tokens created by this wallet in the given window. Exiting.");
    return;
  }

  // --- Step 4 (graph needs ALT events first, computed once for all mints) ---
  console.log("[3/6] Building associated wallet graph (funders + siblings)…");
  const graph = await buildAssociatedWalletGraph(
    connection,
    devWallet,
    altEvents,
    config.startTime,
    config.endTime
  );
  console.log(`  associated wallet set size: ${graph.size}`);

  // --- Steps 3 & 5: for each created mint, pull all txs and classify trades ---
  const allTrades: Trade[] = [];
  for (const creation of creations) {
    console.log(`[4/6] Fetching transactions for mint ${creation.mint} (${creation.source})…`);
    const mintPk = new PublicKey(creation.mint);
    const mintSigs = await fetchMintTransactions(
      connection,
      mintPk,
      config.startTime,
      config.endTime
    );
    console.log(`  ${mintSigs.length} transaction(s) touched this mint in window`);

    console.log(`[5/6] Classifying trades for associated wallets…`);
    for (const sigInfo of mintSigs) {
      const trades = await extractTradesFromTx(connection, sigInfo, mintPk, graph);
      allTrades.push(...trades);
    }
  }
  console.log(`  ${allTrades.length} trade leg(s) attributed to associated wallets`);

  // --- Step 6: PnL rollup ---
  console.log("[6/6] Computing PnL and writing output…");
  const pnlRows = computePnl(allTrades);

  fs.mkdirSync(config.outDir, { recursive: true });
  const csvPath = path.join(config.outDir, "trades_pnl.csv");
  const jsonPath = path.join(config.outDir, "trades_pnl.json");
  const graphPath = path.join(config.outDir, "associated_wallets.json");

  fs.writeFileSync(csvPath, toCsv(pnlRows));
  fs.writeFileSync(jsonPath, JSON.stringify(pnlRows, null, 2));
  fs.writeFileSync(
    graphPath,
    JSON.stringify(Object.fromEntries(graph), null, 2)
  );

  printConsoleSummary(pnlRows, graph);
  printAsciiPnlChart(pnlRows);

  console.log(`\nWrote:\n  ${csvPath}\n  ${jsonPath}\n  ${graphPath}`);
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
